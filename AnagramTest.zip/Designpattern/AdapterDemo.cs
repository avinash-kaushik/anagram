﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Xml.Serialization;
using System.Xml;
using System.IO;


namespace Designpattern
{
    public interface IEmployee
    {
        string GetAllEmployee();
    }

    [Serializable]
    public class EmployeeNew
    {
        [XmlAttribute]
        public string ID { get; set; }
        [XmlAttribute]
        public string Name { get; set; }

        public EmployeeNew(string id, string name)
        {
            this.ID = id;
            this.Name = name;
        }

    }

    public class EmployeeManager
    {
        public List<EmployeeNew> employees;
        public EmployeeManager()
        {
            employees = new List<EmployeeNew>();
            this.employees.Add(new EmployeeNew("1", "john"));
            this.employees.Add(new EmployeeNew("2", "jhonny"));
            this.employees.Add(new EmployeeNew("3", "janardhan"));
        }

        public virtual string GetAllEmployee()
        {
            var emptyNamespace = new XmlSerializerNamespaces(new[] { XmlQualifiedName.Empty });
            var serializer = new XmlSerializer(employees.GetType());
            var settings = new XmlWriterSettings();
            settings.Indent = true;
            settings.OmitXmlDeclaration = true;
            using (var stream = new StringWriter())
            using (var writer = XmlWriter.Create(stream, settings))
            {
                serializer.Serialize(writer, employees, emptyNamespace);
                return stream.ToString();
            }
        }
    }


    public class AdapterDemo
    {
        static void Main(string[] args)
        {
            IEmployee emp = new EmployeeAdapter();
            string value = emp.GetAllEmployee();
            Console.ReadLine();
        }
    }
}
