﻿using System;
using System.Collections.Generic;
using System.Text;
using static System.Console;

namespace Designpattern
{
    class Delegates
    {
        public delegate void SomeMethodPtr();
        static void Main(string[] args)
        {
            SomeMethodPtr obj = new SomeMethodPtr(Method);
            obj.Invoke();
        }

        public static void Method()
        {
            WriteLine("Hello");
        }

    }
}
