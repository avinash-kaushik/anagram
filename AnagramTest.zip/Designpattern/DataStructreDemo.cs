﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Designpattern
{
    class DataStructreDemo
    {

        //O(1)
        public void function1(List<string> data)
        {
            string str = data[0];
        }

        //O(n) -- the time required depend upon input data
        public void function2(List<string> data)
        {
            foreach (var item in data)
            {
                if (item == "Avinash")
                {
                    return;
                }
            }
        }

        //O(2n) or O(n^2)
        public void function3(List<string> data)
        {
            foreach (var item in data)
            {
                foreach (var item1 in data)
                {
                }
            }
        }
    }
}
