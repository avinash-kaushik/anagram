﻿using System;
using System.Collections.Generic;
using System.Text;
using static System.Console;
using System.Collections;

namespace Designpattern
{
    public partial class Employee
    {
        public string ID { get; set; }
        public string Name { get; set; }

        public string DepartmentID { get; set; }
        //public Address EmpAddress { get; set; }

        //public Employee ShallowCopy()
        //{
        //    return (Employee)this.MemberwiseClone();
        //}

        //public Employee DeepCopy()
        //{
        //    Employee other = (Employee)this.MemberwiseClone();
        //    other.EmpAddress = new Address(this.EmpAddress.Houseno, this.EmpAddress.Street);
        //    return other;
        //}

        public override string ToString()
        {
            return string.Format(string.Format("{0}, {1}, {2} ", this.ID, this.Name, this.DepartmentID));
        }
    }

    public partial class Employee : ICloneable
    {
        public object Clone()
        {
            return this.MemberwiseClone();
        }
    }
    public class Address
    {
        public string Houseno { get; set; }
        public string Street { get; set; }

        public Address(string houseno, string street)
        {
            this.Houseno = houseno;
            this.Street = street;

        }

        public override string ToString()
        {
            return string.Format(string.Format("{0}, {1}", this.Houseno, this.Street));
        }
    }

    public class DeepCopyDemo
    {
        static void Main(string[] args)
        {


            ShallowCopy();

            //Employee shallow = (Employee)emp.ShallowCopy();
            //WriteLine(shallow.ToString());

            //Employee deep = (Employee)emp.DeepCopy();
            //WriteLine(deep.ToString());

            ReadLine();
        }

        public static void ShallowCopy()
        {
            Employee empavinsh = new Employee()
            {
                Name = "Avinash",
                ID = "101",
                DepartmentID="150"
            };
            WriteLine(empavinsh.ToString());

            Employee empsam = (Employee)empavinsh.Clone();
            empsam.Name = "Sam Paul";

            WriteLine(empsam.ToString());

            WriteLine("After changing Department Id to 160");
            empavinsh.DepartmentID = "160";

            WriteLine(empavinsh.ToString());
            WriteLine(empsam.ToString());

            ReadLine();
        }
    }
}
