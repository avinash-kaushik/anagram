﻿using System;
using System.Collections.Generic;
using System.Text;
using System.IO;
using static System.Console;
using Unity;
using Unity.Injection;

namespace Designpattern
{
    public class anagrams
    {
        static void Main(string[] args) //string [] means the list of parameters are passed to function. We cannot add any other parameters
        {
            WriteLine("Enter the word");
            string word = ReadLine();
            var path = @"D:\\DesignPattern\\Designpattern\\Wordlist.txt";
            IUnityContainer objContainer = new UnityContainer();
            objContainer.RegisterType<IAnagramRepository, AnagramImplment>();
            AnagramImplment anagramImplment = objContainer.Resolve<AnagramImplment>();
            var Anagram_list = anagramImplment.GetMathcingString(path, word);
            foreach (var item in Anagram_list)
            {
                WriteLine(item);
            }

            ReadLine();
        }

        public static bool calculation<T>(T value1, T value2)
        {
            return value1.Equals(value2);
        }
    }
    public class AnagramImplment : IAnagramRepository
    {
        public List<string> GetMathcingString(string path, string word)
        {
            string[] enumLines = File.ReadAllLines(path, Encoding.UTF8);
            List<string> final_list = new List<string>();

            char[] char1 = word.ToLower().ToCharArray();
            Array.Sort(char1);
            string newWord = new string(char1);

            foreach (var line in enumLines)
            {
                char[] char2 = line.ToLower().ToCharArray();
                Array.Sort(char2);
                string sortedWord = new string(char2);

                if (sortedWord == newWord)
                {
                    final_list.Add(line);
                }
            }
            return final_list;
        }
    }
}


