﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Designpattern
{
    public class Document
    {
        public string Name;
    }
    public interface Iprinter
    {
        public void Print(Document d);
    }

    public interface IScanner
    {
        public void Scan(Document d);
    }

    public class PhotoCopier:Iprinter, IScanner
    {
        public void Print(Document d)
        {
            throw new NotImplementedException();
        }

        public void Scan(Document d)
        {
            throw new NotImplementedException();
        }
    }

    public interface IMultiFunctionDevice: Iprinter, IScanner
    {
        
    }

    public class Multifunction : IMultiFunctionDevice
    {
        public Iprinter Printer;
        public IScanner Scanner;
       
        public Multifunction(Iprinter printer, IScanner scanner)
        {
            this.Printer = printer;
            this.Scanner = scanner;
        }

        public void Print(Document d)
        {
            Printer.Print(d);
        }

        public void Scan(Document d)
        {
            Scanner.Scan(d);
        }
    }

    public class InterfaceSegregation
    {
        static void Main(string[] args)
        {
        }
    }
}
