﻿using System;
using System.Collections.Generic;
using static System.Console;
using System.Threading;
using System.Threading.Tasks;

namespace Designpattern
{
    public class Asynctest
    {
        static void Main(string[] args)
        {
            int[] arr = new int[] { 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10 };
            Parallel.For(0, arr.Length, i =>
                  {
                      WriteLine("task started {0}", i);
                      Thread.Sleep(1000);
                      WriteLine("task ended {0}", i);
                  });
            //Parallel.Invoke(() => Method(1, 1000), () => Method(2, 2000), () => Method(3, 3000));
            //t1.Start();
            //var t2 = Task.Factory.StartNew(() => Method(2, 2000));
            //var t3 = Task.Factory.StartNew(() => Method(3, 1000));
            ReadLine();
        }

        static void Method(int id, int sleep)
        {
            WriteLine("Task {0} started", id);
            Thread.Sleep(sleep);
            WriteLine("Task {0} Ended", id);
        }

        //public static void WaitTask()
        //{
        //    Thread.Sleep(5000);
        //}

    }
}
