﻿using System;
using System.Collections.Generic;
using System.Text;
using static System.Console;

namespace Designpattern
{

    public class HtmlElement
    {
        public string Name, Text;
        public List<HtmlElement> Elements = new List<HtmlElement>();
        private int indentSize = 2;

        public HtmlElement(string name, string text)
        {
            Name = name ?? throw new ArgumentNullException(paramName: nameof(name));
            Text = text ?? throw new ArgumentNullException(paramName: nameof(text));
        }

    }
    public class BuilderDemo
    {
        static void Main(string[] args)
        {
            var hello = "Hello";
            var sb = new StringBuilder();
            sb.Append("<p>");
            sb.Append(hello);
            sb.Append("</p>");
            WriteLine(sb.ToString());

            var words = new[] { "Hello", "Avinash" };
            sb.Clear();
            sb.Append("<ul>");
            foreach (var item in words)
            {
                sb.AppendFormat("<Li> {0} </Li>", item);
            }
            sb.Append("</ul>");
            WriteLine(sb.ToString());
        }
    }
}
