﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Designpattern
{
    public class Rectangle
    {
        public virtual int Width { get; set; }
        public virtual int Height { get; set; }

        public Rectangle()
        {

        }

        public Rectangle(int width, int height)
        {
            this.Height = height;
            this.Width = width;
        }

        public override string ToString()
        {
            return $"{nameof(Width)}: {Width}, {nameof(Height)}: {Height} ";
        }
    }

    public class Square : Rectangle
    {
        public override int Width
        {
            set
            {
                base.Width = base.Height = value;
            }
        }
        public override int Height
        {
            set
            {
                base.Height = base.Width = value;
            }
        }
    }
    public class LiskovDemo
    {
        static void Main(string[] args)
        {
            static int Area(Rectangle r) => r.Width * r.Height;
            Rectangle rec = new Rectangle();
            rec.Width = 10;
            rec.Height = 5;
            Console.WriteLine($"{rec} has Area {Area(rec)}");

            Rectangle sq = new Square();
            sq.Height = 9;
            Console.WriteLine($"{sq} has Area {Area(sq)}");

        }
    }
}
