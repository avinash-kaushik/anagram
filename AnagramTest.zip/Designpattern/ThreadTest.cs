﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading;
using static System.Console;

namespace Designpattern
{
    public class ThreadTest
    {
        static void Main(string[] args)
        {
            //Thread obj1 = new Thread(function1);
            Thread obj2 = new Thread(function2);
            //obj1.Start();
            obj2.IsBackground = true;
            obj2.Start();
            WriteLine("Main Function exited");
        }

        //static void function1()
        //{
        //    for (int i = 0; i < 10; i++)
        //    {
        //        WriteLine(string.Format("value of i {0}", i.ToString()));
        //    }
        //}

        static void function2()
        {
            WriteLine("Function Executing");
            ReadLine();
            WriteLine("Function exited");
            //for (int i = 0; i < 10; i++)
            //{
            //    WriteLine(string.Format("value of i {0} in fun2", i.ToString()));
            //}
        }
    }
}
