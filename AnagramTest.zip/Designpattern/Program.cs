﻿using System;
using System.IO;
using System.Collections.Generic;
using System.Linq;
using System.Diagnostics;
using static System.Console;
using System.Threading;
using System.Threading.Tasks;

namespace Designpattern
{

    public class journol
    {
        private readonly List<string> enteris = new List<string>();
        private static int count = 0;
        public int AddEntry(string text)
        {
            enteris.Add($"{++count}: {text}");
            return count;
        }

        public void RemoveEntry(int index)
        {
            enteris.RemoveAt(index);
        }

        public override string ToString()
        {
            return string.Join(Environment.NewLine, enteris);
        }


    }

    public class Persistence
    {
        public void SaveToFile(journol j, string FileName, bool overwrite = false)
        {
            if (overwrite || !File.Exists(FileName))
                File.WriteAllText(FileName, j.ToString());
        }

        //public static journol Load(string FileName)
        //{

        //}
    }
    public class Demo
    {
        static void Main(string[] args)
        {
            Parallel.Invoke(
            () => FirstMethod(),
            () => SecondMethod()
            );
            ReadLine();

        }

        private static void SecondMethod()
        {
            SingleTonDemo s2 = SingleTonDemo.GetInstance;
            s2.PrintDetails("This is Second Message");
        }

        private static void FirstMethod()
        {
            SingleTonDemo s1 = SingleTonDemo.GetInstance;
            s1.PrintDetails("This is first Message");
        }
        //static void Main(string[] args)
        //{
        //    var j = new journol();
        //    j.AddEntry("This is first line");
        //    j.AddEntry("This is second line");
        //    Console.WriteLine(j);

        //    Persistence p = new Persistence();
        //    string fileName = @"D:\Tempdata.txt";
        //    p.SaveToFile(j, fileName, true);
        //    //Process.Start(fileName);
        //}
    }
}
