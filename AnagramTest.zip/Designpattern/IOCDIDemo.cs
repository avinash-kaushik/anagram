﻿using System;
using System.Collections.Generic;
using System.Text;
using static System.Console;
using Unity;
using Unity.Injection;

namespace Designpattern
{
    public class IOCDIDemo
    {
        static void Main(string[] args)
        {
            IUnityContainer objContainer = new UnityContainer();
            objContainer.RegisterType<Customer>();

            objContainer.RegisterType<IDAL, OracleDAL>();
            objContainer.RegisterType<IDAL, SQLServerDAL>("SQL");

            objContainer.RegisterType<Customer>("sqlDriver", new InjectionConstructor(objContainer.Resolve<IDAL>("SQL")));


            //Customer user = objContainer.Resolve<Customer>();
            //user.name = "FirstName";
            //user.add();

            Customer user2 = objContainer.Resolve<Customer>();
            user2.name = "FirstName";
            user2.add();

            Customer user3 = objContainer.Resolve<Customer>("sqlDriver");
            user3.name = "FirstName";
            user3.add();
        }
        class Customer
        {
            public string name { get; set; }
            IDAL dal;
            public Customer(IDAL obj)
            {
                dal = obj;
            }
            public void add()
            {

                dal.Add(this);
            }
        }

        interface IDAL
        {
            void Add(Customer customer);
        }
        class SQLServerDAL : IDAL
        {
            public void Add(Customer customer)
            {
                WriteLine("SQL server Inserted " + customer.name);
            }
        }

        class OracleDAL : IDAL
        {
            public void Add(Customer customer)
            {
                WriteLine("Oracle server Inserted " + customer.name);
            }
        }
    }
}
