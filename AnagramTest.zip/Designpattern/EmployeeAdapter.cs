﻿using System;
using System.Collections.Generic;
using System.Text;
using Newtonsoft.Json;
using System.Xml;
namespace Designpattern
{
    public class EmployeeAdapter : EmployeeManager, IEmployee
    {
        public override string GetAllEmployee()
        {
            string returnXML = base.GetAllEmployee();
            XmlDocument doc = new XmlDocument();
            doc.LoadXml(returnXML);
            return null;
            //return JsonConverter.Se(doc, Newtonsoft.Json.Formatting.Indented);
        }

    }
}
