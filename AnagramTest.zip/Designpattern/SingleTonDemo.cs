﻿using System;
using System.Collections.Generic;
using System.Text;
using static System.Console;

namespace Designpattern
{
    public sealed class SingleTonDemo
    {
        private static int counter = 0;

        public static readonly Lazy<SingleTonDemo> instance = new Lazy<SingleTonDemo>(()=> new SingleTonDemo());
        //private static readonly object obj = new object();
        public static SingleTonDemo GetInstance
        {
            get
            {
                //if (instance == null)
                //{
                //    lock (obj)
                //    {
                //        if (instance == null)
                //            instance = new SingleTonDemo();
                //    }
                //}
                return instance.Value;
            }
        }
        private SingleTonDemo()
        {
            counter++;
        }

        public void PrintDetails(string message)
        {
            WriteLine(message);
            WriteLine(counter.ToString());
        }


    }
}
