﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Designpattern
{
    interface IAnagramRepository
    {
        List<string> GetMathcingString(string path, string word);
    }
}
